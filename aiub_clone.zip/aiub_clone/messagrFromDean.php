<?php
// message_from_dean.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Message from the Dean - Faculty of Engineering</title>
  <link rel="stylesheet" href="messageFromDean.css" />
</head>
<body>
  <header>
    <h1>Faculty of Engineering</h1>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Faculties</a></li>
        <li><a href="#">Research</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="dean-message">
      <h2>Message from the Dean</h2>
      <img src="dean.jpg" alt="Dean's Photo" class="dean-photo" />
      <p>
        Electrical and Electronic Engineering is concerned with the design, research, development, planning, manufacture, and management of systems and devices relying on electricity and light to transmit data and power, which underpin modern economies and contribute to the quality of human life. Many of these devices rely on the use of new information and computer-intensive technologies.
      </p>
      <p>
        An Electrical Engineer may be responsible for research, design, manufacture, and operation of communication systems, satellite, microwave, optical, telecommunications, broadcasting, radio and television, solar energy conversion, electric power generation, transmission and distribution, computer networks, microprocessors, instrumentation and consumer devices, automatic control systems and robotics, electronic and integrated circuits, image processing systems, electrical machines, electromechanical equipment, biomedical engineering, and many other areas.
      </p>
      <p>
        Currently, more than 3000 students are pursuing their four-year undergraduate studies in the Department of Electrical & Electronic Engineering. The Master's programs in Electrical and Electronic Engineering, Telecommunication Engineering, and Computer Science are designed with advanced specialized courses and provide research opportunities to students as well as faculty members. AIUB provides the country's most advanced laboratories with cutting-edge technologies to cope with modern challenges in the fields of Circuits, Electronics and Devices, Power Engineering, Computers, and Communication Engineering.
      </p>
      <p>
        AIUB imparts engineering education through a prescribed curriculum, approved by the University Grants Commission (UGC) and accredited by international as well as national professional bodies. The curriculum is at par with that at other world universities. It encompasses the knowledge and wisdom of engineering discoveries and innovations spanning a period of a few hundred years. As such, the study of electrical engineering is fulfilling and at the same time challenging. It requires students of better than average capabilities. AIUB has recognized from the very beginning that these students need and deserve better than average facilities and environment for their optimum development. An excellent faculty team has been engaged to nurture its students.
      </p>
      <p>
        The AIUB EEE program has been operating for more than ten years with name and fame; its lab and other infrastructure required to ensure a quality teaching-learning environment are quite strong. Its graduates are engaged in work and in higher education all over the world. Admission of new students in this program is competitive. In summary, the program is well-established and sustainable. AIUB is committed to providing quality education.
      </p>
      <p>
        Yours Sincerely,<br/>
        <strong>Dr. A B M Siddique Hossain</strong><br/>
        Dean<br/>
        Faculty of Engineering<br/>
        American International University-Bangladesh (AIUB)
      </p>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 American International University-Bangladesh</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
