<?php
session_start();
if (!isset($_SESSION['student'])) {
    header("Location: student_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "aiub_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student'];

// fetch class schedule
$stmt = $conn->prepare("
    SELECT s.*, c.course_code, c.course_name 
    FROM schedules s 
    JOIN courses c ON c.course_id = s.course_id
    WHERE s.student_id = ? AND s.type = 'class'
    ORDER BY FIELD(s.day_of_week, 'Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), s.start_time
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$class_result = $stmt->get_result();

// fetch exam schedule
$stmt2 = $conn->prepare("
    SELECT s.*, c.course_code, c.course_name 
    FROM schedules s 
    JOIN courses c ON c.course_id = s.course_id
    WHERE s.student_id = ? AND s.type = 'exam'
    ORDER BY s.date
");
$stmt2->bind_param("i", $student_id);
$stmt2->execute();
$exam_result = $stmt2->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Schedule</title>
<style>
body {
    font-family: Arial;
    background: #f5f5f5;
    margin:0; padding:20px;
}
h1 {
    color:#004080;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 30px;
}
th, td {
    border: 1px solid #ddd;
    padding: 8px;
}
th {
    background: #004080;
    color: white;
}
tr:nth-child(even) { background: #f2f2f2; }
a {
    color: #007bff;
    text-decoration: none;
}
</style>
</head>
<body>

<h1>📅 My Schedule</h1>

<h2>Class Schedule</h2>
<?php if ($class_result->num_rows > 0): ?>
<table>
    <tr>
        <th>Day</th>
        <th>Time</th>
        <th>Course</th>
        <th>Room</th>
    </tr>
<?php while($row = $class_result->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($row['day_of_week']) ?></td>
    <td><?= htmlspecialchars($row['start_time']) ?> - <?= htmlspecialchars($row['end_time']) ?></td>
    <td><?= htmlspecialchars($row['course_code']) ?> - <?= htmlspecialchars($row['course_name']) ?></td>
    <td><?= htmlspecialchars($row['room']) ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php else: ?>
<p>No class schedule found.</p>
<?php endif; ?>


<h2>Exam Schedule</h2>
<?php if ($exam_result->num_rows > 0): ?>
<table>
    <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Course</th>
        <th>Room</th>
    </tr>
<?php while($row = $exam_result->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($row['date']) ?></td>
    <td><?= htmlspecialchars($row['start_time']) ?> - <?= htmlspecialchars($row['end_time']) ?></td>
    <td><?= htmlspecialchars($row['course_code']) ?> - <?= htmlspecialchars($row['course_name']) ?></td>
    <td><?= htmlspecialchars($row['room']) ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php else: ?>
<p>No exam schedule found.</p>
<?php endif; ?>

<p><a href="index.php">← Back to Home</a></p>

</body>
</html>
<?php
$stmt->close();
$stmt2->close();
$conn->close();
?>
