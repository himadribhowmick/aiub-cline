<?php
// campus-entry-policy.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Campus Entry Policy</title>
  <link rel="stylesheet" href="rules.css" />
</head>
<body>
  <section class="policy-container">
    <h1>AIUB Campus Entry Policy</h1>

    <div class="policy-block">
      <h2>1. ID Requirement</h2>
      <p><strong>NO ID; NO ENTRY</strong> policy is strictly applicable for the Students and Employees of the university. Students and Employees must wear their Proper AIUB ID card, with the attached color-coded ribbons of their respective faculties before entering the campus and the ID card must be visible at all times inside the campus.</p>
    </div>

    <div class="policy-block">
      <h2>2. Facial Recognition System</h2>
      <p>The Facial Recognition System implemented at the automated flap gates throughout the campus entry points will grant access for valid registered students of the current semester. <strong>Note:</strong> It is NOT a supplement to the student ID card.</p>
    </div>

    <div class="policy-block">
      <h2>3. System Access Issues</h2>
      <p>If the Facial Recognition System does not grant access to a valid registered student, due to mechanical error or any other issue, they may use the designated bay to access entry points with the Student IDs. Afterwards, they must proceed to the VUES Office to resolve the issue to avoid further restrictions on campus entry.</p>
    </div>

    <div class="policy-block">
      <h2>4. Unregistered Students</h2>
      <p>Unregistered/invalid students carrying their Student ID cards must verify their status at the validation kiosk or at the Office of the Registrar for processing entry access requests.</p>
    </div>

    <div class="policy-block">
      <h2>5. Alumni Access</h2>
      <p>Registered members of the <strong>AIUB Alumni Society (AIUB AlumS)</strong> must present their membership card to gain campus access. Other alumni may acquire a one-day alumni pass from the designated office in the Gallery. They may later contact the <strong>Office of Placement & Alumni (OPA)</strong> for more information on becoming registered members.</p>
    </div>

    <div class="policy-block">
      <h2>6. Visitor/Guardian Entry</h2>
      <p>Visitors and guardians are allowed for valid and verified reasons only. Pre-set appointments must be cross-checked and confirmed. Visitors must submit a valid Photo ID and collect an official Visitor ID from the reception/security desk near the Registrar’s Office. Visitor IDs must be worn visibly at all times and returned upon exit to reclaim their submitted Photo ID.</p>
    </div>

    <div class="policy-block">
      <h2>7. Guest Requests by Students</h2>
      <p>Student guest entry requests are processed on a case-by-case basis, subject to validation of the guest’s photo ID and the student’s ID.</p>
    </div>

    <div class="policy-block">
      <h2>8. Gate Usage Policy</h2>
      <p>Gates marked with ‘No Entry’ signage are for <strong>Exit only</strong>. Students must follow the designated entry and exit routes. Violations may lead to disciplinary action.</p>
    </div>

    <div class="policy-block">
      <h2>9. Dress Code</h2>
      <ul>
        <li>Male students must wear closed-toe shoes (front and back fully covered) at all times.</li>
        <li>All students must be properly attired. Any indecent, inappropriate, or immodest attire that violates the university code of conduct may lead to dismissal or disciplinary action.</li>
      </ul>
    </div>

    <div class="policy-block">
      <h2>10. Final Authority</h2>
      <p>The AIUB Management reserves the right to permit, restrict, or dismiss anyone from entering the campus premises at any time.</p>
    </div>
  </section>
</body>
</html>
