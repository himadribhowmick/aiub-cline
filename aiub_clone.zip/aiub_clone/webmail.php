<?php
// webmail_login.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Microsoft Sign In</title>
  <link rel="stylesheet" href="webmail.css">
  <link rel="icon" type="image/png" href="image/aiublogo.png">
</head>
<body>
  <div class="main-container">
    <div class="login-box">
      <img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg" alt="Microsoft Logo">
      <h2>Sign in</h2>
      <input type="text" placeholder="Email, phone, or Skype" class="input-field">
      <div class="links">
        <p>No account? <a href="#">Create one!</a></p>
        <a href="#">Can’t access your account?</a>
      </div>
      <button class="next-btn">Next</button>
    </div>

    <div class="options-box">
      <img src="https://img.icons8.com/ios-filled/20/000000/search.png" alt="Sign-in options icon">
      <span>Sign-in options</span>
    </div>
  </div>
</body>
</html>
