<?php
// orp.php - Office of Research and Publications Page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ORP | AIUB</title>
  <link rel="stylesheet" href="orp.css" />
</head>
<body>
  <!-- Header -->
  <header class="top-bar">
    <div class="logo">
      <img src="https://www.aiub.edu/Content/Logo/aiub_logo_sm.png" alt="AIUB Logo">
      <div class="title">
        <h1>AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH</h1>
        <p>where leaders are created</p>
      </div>
    </div>
    <div class="search-box">
      <input type="text" placeholder="type your search" />
      <button>🔍</button>
    </div>
  </header>

  <!-- Navigation -->
  <nav class="main-nav">
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">AJBE</a></li>
      <li><a href="#">AJSE</a></li>
      <li><a href="#">Working Paper</a></li>
      <li><a href="#">Faculty Journal</a></li>
      <li><a href="#">Publications ▾</a></li>
      <li><a href="#">Links ▾</a></li>
      <li><a href="#">Contact</a></li>
      <li><a href="#">AIUB</a></li>
      <li><a href="#">Web Mail</a></li>
      <li><a href="#">Login</a></li>
    </ul>
  </nav>

  <!-- Banner -->
  <section class="banner">
    <img src="https://www.aiub.edu/Files/Uploads/hand-writing-book.jpg" alt="Writing" />
    <div class="caption">
      <p>Office of Research and Publications [ORP]<br>American International University-Bangladesh</p>
    </div>
  </section>

  <!-- Notices -->
  <section class="info-section">
    <div class="info-box">
      <h3>Introduction</h3>
      <p class="alert">Not Found! There is no recent News.</p>
    </div>
    <div class="info-box">
      <h3>News & Events</h3>
      <p class="alert">Not Found! There is no recent News & Events.</p>
    </div>
    <div class="info-box">
      <h3>Notices</h3>
      <p class="alert">Not Found! There is no recent Notices.</p>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="quick-search">
      <h4>QUICK SEARCH</h4>
      <p>
        2014 Registration Admission Graduation BBA CSE Dr. Carmen Z. Lamagna EEE Project IEEE Memorandum ISO 9001:2008
      </p>
    </div>
    <div class="footer-mid">
      <img src="https://www.aiub.edu/Content/Logo/aiub_logo_sm.png" alt="AIUB Logo" />
      <p>Founded in 1994</p>
      <address>
        American International University-Bangladesh (AIUB)<br>
        408/1, Kuratoli, Khilkhet, Dhaka 1229, Bangladesh<br>
        info@aiub.edu
      </address>
    </div>
    <div class="subscribe-box">
      <h4>SUBSCRIBE US</h4>
      <p>Subscribe to our latest information and stay tuned!</p>
      <input type="email" placeholder="Email Address" />
      <button>Subscribe</button>
    </div>
  </footer>

  <div class="bottom-bar">
    <p>2000–2025 © American International University-Bangladesh | Powered by <a href="#">AIUB Software Division</a></p>
  </div>
</body>
</html>
