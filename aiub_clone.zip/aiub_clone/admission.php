<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admission | AIUB</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="icon" type="fevicon" href="image/aiublogo.png">
  
</head>
<body>
 <!-- Header -->
 <header class="top-header">
  <!-- Top Info Bar -->
<div class="top-info-bar">
<div class="left-text">
  American International University-Bangladesh
</div>
<div class="right-links">
    <span class="icon">🔍</span>
    <a href="login.html">Login</a> |
    <a href="webmail.html">Web Mail</a> |
    <a href="contract_us.html">Contact Us</a>
  </div>
</div>

  <div class="main-header">
    <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
    <nav class="navbar">
      <a href="index.php">Home</a>
      <a href="about.php">About</a>
      <a href="academic.php">Academic</a>
      <a href="administration.php">Administration</a>
      <a href="admission.php">Admission</a>
      <a href="research.php">Research</a>
      <a href="notice.php">Notice</a>
      <a href="contract_us.php">Contact</a>
    </nav>
  </div>
</header>

  <!-- Admission Content -->
  <main class="admission-page">
    <section class="admission-schedule">
      <h2>Admission Schedule</h2>
      <table class="schedule-table">
        <tr><td>Online Admission Form Opens</td><td>MARCH 11, 2025 (Thursday)</td></tr>
        <tr><td class="highlight">[Except B.Pharm & LLB]</td><td></td></tr>
        <tr><td>Deadline for Online Admission Form Submission</td><td>APRIL 27, 2025 (Sunday)</td></tr>
        <tr><td>Deadline for Payment</td><td>APRIL 29, 2025 (Tuesday)</td></tr>
        <tr><td>Admission Written Exam</td><td>MAY 02, 2025 (Thursday)</td></tr>
        <tr><td>Written Result</td><td>MAY 13, 2025 (Tuesday)</td></tr>
        <tr><td>Viva</td><td>MAY 14 & 15, 2025</td></tr>
        <tr><td>Final Result</td><td>MAY 18, 2025 (Sunday)</td></tr>
        <tr><td>Admission & Registration</td><td>MAY 19 - 21, 2025</td></tr>
        <tr><td>Freshmen Class Starts</td><td>JULY 07, 2025 (Tentative)</td></tr>
      </table>
    </section>

    <section class="admission-requirements">
      <h3>Admission Requirements</h3>
      <button><a href="undergraduatePrograms.html">Undergraduate Program Requirements</a></button>
      <button><a href="graduatePrograms.html">Graduate Program Requirements</a></button>
    </section>

    <section class="admission-policy">
      <div class="policy-box">
        <h4>Non-Discriminatory Admission Policy</h4>
        <p>AIUB admits qualified students regardless of age, gender, religion, etc.</p>
        <button><a href="non_discriminatory_add.html">Details</a></button>
      </div>
      <div class="policy-box">
        <h4>Policy for Students with Disability</h4>
        <button><a href="students_disability.html">Details</a></button>
      </div>
      <div class="policy-box">
        <h4>Policy for Underrepresented Group</h4>
        <button><a href="underrepresented_group.html">Details</a></button>
      </div>
    </section>

    <section class="international-students">
      <h3>International Students</h3>
      <p>A degree from AIUB is a great investment...</p>
      <button><a href="international_students.html">View Details</a></button>
    </section>

    <section class="fees-scholarships">
      <h3>Fees & Scholarships</h3>
      <button><a href="tuition_fees.html">Tuition Fees</a></button>
      <button><a href="scholarships.html">Scholarships</a></button>
    </section>

    <section class="apply-now">
      <h3>Apply Now</h3>
      <ol>
        <li>Login: <a href="http://admission.aiub.edu">admission.aiub.edu</a></li>
        <li>Fill up required fields</li>
        <li>Upload photo and academic documents</li>
        <li>Print Admit Card</li>
        <li>Verify within 72 hours</li>
        <li>Download Admit Card</li>
        <li>Bring Admit Card on Exam Day</li>
      </ol>
      <button class="apply-btn"><a href="apply_online.php">Apply Online</a></button>
    </section>

    <section class="sample-question">
      <h3>Sample Question</h3>
      <div class="sample-grid">
        <div class="sample-box fst"><a href="fst-&-fe-sample-question.pdf" target="_blank">FST Sample Question PDF</a></div>
        <div class="sample-box fe"><a href="fst-&-fe-sample-question.pdf" target="_blank">FE Sample Question PDF</a></div>
        <div class="sample-box fba"><a href="bba-sample-question.pdf" target="_blank">BBA/MBA Sample PDF</a></div>
        <div class="sample-box fass"><a href="fass-sample-question.pdf" target="_blank">FASS Sample PDF</a></div>
      </div>
      <p class="note">Application Form Price: BDT 1000.00 (non-refundable)</p>
    </section>
  </main>

  <footer class="footer about-footer">
    <div class="footer-content">
      <div class="footer-left">
        <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
        <p>American International University-Bangladesh (AIUB)</p>
        <p>Where leaders are created</p>
        <div class="social-icons">
          <a href="#"><img src="image/fb.jpeg" alt="Facebook"></a>
          <a href="#"><img src="image/twt.png" alt="Twitter"></a>
          <a href="#"><img src="image/lindin.png" alt="LinkedIn"></a>
          <a href="#"><img src="image/yt.png" alt="YouTube"></a>
        </div>
      </div>
      <div class="footer-center">
        <h4>Contact</h4>
        <p>Email: info@aiub.edu</p>
        <p>Address: 408/1 (Old KA 66/1), Kuratoli, Khilkhet, Dhaka-1229</p>
        <p>Phone: +88 02 841 4046-9; +88 02 841 4050</p>
      </div>
      <div class="footer-right">
        <h4>Become AIUBian</h4>
        <ul>
          <li><a href="#">Future Students</a></li>
          <li><a href="#">On Campus</a></li>
          <li><a href="#">Admission</a></li>
          <li><a href="#">Tuition Fees</a></li>
          <li><a href="#">Scholarships</a></li>
          <li><a href="#">Apply Now</a></li>
        </ul>
        <h4>Academic</h4>
        <ul>
          <li><a href="#">Academic Calendar</a></li>
          <li><a href="#">Academic Regulations</a></li>
          <li><a href="#">Faculty of Arts & Social Sciences</a></li>
          <li><a href="#">Faculty of Business Administration</a></li>
          <li><a href="#">Faculty of Engineering</a></li>
          <li><a href="#">Faculty of Science & Technology</a></li>
        </ul>
      </div>
    </div>
  </footer>
</body>
</html>
