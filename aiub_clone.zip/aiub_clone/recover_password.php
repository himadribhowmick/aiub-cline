<!DOCTYPE html>
<html>
<head>
<title>Recover Password</title>
</head>
<body>

<h2>Recover Password</h2>

<p>To reset your password, please contact the university administration or email support@example.edu.</p>

<p><a href="student_login.php">Back to Login</a></p>

</body>
</html>
