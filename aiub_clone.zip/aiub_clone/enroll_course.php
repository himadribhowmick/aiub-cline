<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
session_start();
if (!isset($_SESSION['student'])) {
    header("Location: student_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "aiub_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student'];

// Handle enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $course_id = intval($_POST['course_id']);

    // Prevent duplicate enrollment
    $check = $conn->prepare("SELECT * FROM student_courses WHERE student_id = ? AND course_id = ?");
    $check->bind_param("ii", $student_id, $course_id);
    $check->execute();
    $result = $check->get_result();
    if ($result->num_rows === 0) {
        $stmt = $conn->prepare("INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
        $stmt->close();
        $msg = "✅ Enrolled successfully!";
    } else {
        $msg = "⚠️ You are already enrolled in this course.";
    }
    $check->close();
}

// Fetch all courses
$courses_result = $conn->query("SELECT * FROM courses ORDER BY course_code");

// Fetch enrolled courses
$stmt = $conn->prepare("
    SELECT c.course_code, c.course_name 
    FROM courses c 
    JOIN student_courses sc ON c.course_id = sc.course_id
    WHERE sc.student_id = ?
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$enrolled_result = $stmt->get_result();

$enrolled = [];
while ($row = $enrolled_result->fetch_assoc()) {
    $enrolled[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Enroll in Courses</title>
<style>
body {
    font-family: Arial;
    background: #f5f5f5;
    margin: 0;
    padding: 20px;
}
h1 {
    color: #004080;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}
th, td {
    border: 1px solid #ddd;
    padding: 8px;
}
th {
    background: #004080;
    color: white;
}
form {
    margin: 0;
}
button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
}
button:hover {
    background-color: #0056b3;
}
.message {
    margin-bottom: 20px;
    padding: 10px;
    background: #e1f3e1;
    color: green;
}
</style>
</head>
<body>

<h1>📚 Enroll in Courses</h1>

<?php if (!empty($msg)): ?>
<div class="message"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<h2>Already Enrolled Courses</h2>
<?php if (!empty($enrolled)): ?>
<table>
<tr>
    <th>Course Code</th>
    <th>Course Name</th>
</tr>
<?php foreach ($enrolled as $e): ?>
<tr>
    <td><?= htmlspecialchars($e['course_code']) ?></td>
    <td><?= htmlspecialchars($e['course_name']) ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php else: ?>
<p>You are not enrolled in any courses yet.</p>
<?php endif; ?>

<h2>Available Courses</h2>
<table>
<tr>
    <th>Course Code</th>
    <th>Course Name</th>
    <th>Action</th>
</tr>
<?php while ($course = $courses_result->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($course['course_code']) ?></td>
    <td><?= htmlspecialchars($course['course_name']) ?></td>
    <td>
        <form method="post">
            <input type="hidden" name="course_id" value="<?= $course['course_id'] ?>">
            <button type="submit">Enroll</button>
        </form>
    </td>
</tr>
<?php endwhile; ?>
</table>

<p><a href="index.php">← Back to Home</a></p>

</body>
</html>
