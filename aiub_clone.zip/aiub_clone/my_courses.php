<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>University Homepage</title>
<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  line-height: 1.6;
}
header {
  background: #004080;
  color: white;
  padding: 20px;
  text-align: center;
}
nav {
  background: #eee;
  display: flex;
  justify-content: center;
  gap: 15px;
  padding: 10px;
}
nav a {
  text-decoration: none;
  color: #004080;
  font-weight: bold;
}
section {
  padding: 40px 20px;
  max-width: 1200px;
  margin: auto;
}
h2 {
  color: #004080;
  text-align: center;
}
.grid {
  display: grid;
  gap: 20px;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  margin-top: 20px;
}
.card {
  background: #f4f4f4;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}
footer {
  background: #004080;
  color: white;
  text-align: center;
  padding: 20px;
}
.hero {
  background: url('image/campus-drone-shot-25-june-2024.webp') center/cover no-repeat;
  height: 300px;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2em;
  text-shadow: 2px 2px 5px rgba(0,0,0,0.5);
}
</style>
</head>
<body>

<header>
  <h1>American International University-Bangladesh</h1>
  <p>Where Leaders are Created</p>
</header>

<nav>
  <a href="#">Home</a>
  <a href="#notices">Notices</a>
  <a href="#news">News & Events</a>
  <a href="#courses">My Courses</a>
  <a href="#faculties">Faculties</a>
  <a href="#admissions">Admissions</a>
  <a href="#research">Research</a>
  <a href="#studentlife">Student Life</a>
  <a href="#contact">Contact</a>
  <a href="student_login.php">Student Login</a>
  <a href="faculty_login.php">Faculty Login</a>
</nav>

<div class="hero">
  Welcome to AIUB
</div>

<section id="notices">
  <h2>📢 Notices & Announcements</h2>
  <div class="grid">
    <?php
    // Example dynamic notices
    $notices = [
        'Notice 1: Class schedule updated',
        'Notice 2: Exam routine published',
        'Notice 3: Campus closed on Friday'
    ];
    foreach ($notices as $notice) {
        echo "<div class='card'>" . htmlspecialchars($notice) . "</div>";
    }
    ?>
  </div>
</section>

<section id="news">
  <h2>📰 News & Events</h2>
  <div class="grid">
    <?php
    $news = [
        'Event 1: Convocation 2025',
        'Event 2: TechFest Hackathon',
        'Event 3: Alumni Meet'
    ];
    foreach ($news as $item) {
        echo "<div class='card'>" . htmlspecialchars($item) . "</div>";
    }
    ?>
  </div>
</section>

<section id="courses">
  <h2>📚 My Courses</h2>
  <p style="text-align:center;">
    <a href="my_courses.php" style="
      display: inline-block;
      padding: 10px 20px;
      background: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 4px;
    ">View My Courses →</a>
  </p>
</section>

<section id="faculties">
  <h2>🏛️ Faculties & Programs</h2>
  <div class="grid">
    <?php
    $faculties = [
        'Faculty of Engineering',
        'Faculty of Business Administration',
        'Faculty of Arts & Social Sciences',
        'Faculty of Science & Technology'
    ];
    foreach ($faculties as $faculty) {
        echo "<div class='card'>" . htmlspecialchars($faculty) . "</div>";
    }
    ?>
  </div>
</section>

<section id="admissions">
  <h2>🎓 Admissions</h2>
  <div class="grid">
    <?php
    $admissions = [
        'How to Apply',
        'Scholarships',
        'Tuition & Fees',
        'Admission Requirements'
    ];
    foreach ($admissions as $admission) {
        echo "<div class='card'>" . htmlspecialchars($admission) . "</div>";
    }
    ?>
  </div>
</section>

<section id="research">
  <h2>🔬 Research & Innovation</h2>
  <div class="grid">
    <?php
    $research = [
        'Research Labs',
        'Publications',
        'Ongoing Projects'
    ];
    foreach ($research as $item) {
        echo "<div class='card'>" . htmlspecialchars($item) . "</div>";
    }
    ?>
  </div>
</section>

<section id="studentlife">
  <h2>🎉 Student Life</h2>
  <div class="grid">
    <?php
    $studentlife = [
        'Clubs & Societies',
        'Sports & Recreation',
        'Campus Life'
    ];
    foreach ($studentlife as $life) {
        echo "<div class='card'>" . htmlspecialchars($life) . "</div>";
    }
    ?>
  </div>
</section>

<section id="contact">
  <h2>📞 Contact & About</h2>
  <p style="text-align:center;">
    Email: info@aiub.edu <br>
    Phone: +8802 8414046-9 <br>
    Address: 408/1 (Old KA 66/1), Kuratoli, Khilkhet, Dhaka-1229
  </p>
</section>

<footer>
  &copy; <?php echo date('Y'); ?> American International University-Bangladesh. All rights reserved.
</footer>

</body>
</html>
