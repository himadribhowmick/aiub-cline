<?php
// info.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AIUB - Information Page</title>
  <link rel="stylesheet" href="info.css" />
</head>
<body>
  <div class="container">
    <h1>Overview of</h1>
    <h2>American International University-Bangladesh</h2>
    <p>
      American International University - Bangladesh (AIUB) is a government approved private university founded in 1994 by Dr. Anwarul Abedin. The university is an independent organization with its own Board of Trustees.
    </p>

    <h3>Initial Government Approval</h3>
    <p>
      The University received its initial Approval for Establishment and Operation on 6th November 1995, available here.
    </p>

    <h3>Permanent Government Approval</h3>
    <p>
      The University was conferred with the certificate of Permanent Establishment and Operation on 25 October 2023, available here.
    </p>

    <h3>Vision</h3>
    <p>
      American International University-Bangladesh continuously transforms the students to become innovative and globally competitive with excellent, state-of-the-art and academic knowledge and skills nurturing their full potentials not only as future leaders in their respective fields of endeavor, but also as unique contributors to the society.
    </p>

    <h3>Mission</h3>
    <p>
      American International University-Bangladesh is committed to provide quality and excellent academic programs responsive to the emerging global challenges. The university is dedicated to produce and foster competent world class graduates imbued with strong sense of ethical values ready to face the competitive world of business, science, technology, engineering and social sciences.
    </p>

    <h3>Quality Policy</h3>
    <p>
      American International University-Bangladesh adheres to quality in conformity with the prescribed national, international, professional and academic standards of quality and excellence. The university is committed to translate its academic programs and projects into actions propagating the best practices and assuring the quality of learning opportunities. The students being the most valued stakeholders are the central focus of the university and are provided with utmost care and attention to meet their primordial needs and future career success. In view of this commitment, the university shall exert best efforts to harmonize its actions through collaboration, cooperation and consultation with every unit and components of the university.
    </p>

    <h3>Goals</h3>
    <ul>
      <li>Sustain academic development and progress of the university</li>
      <li>Upgrade educational services and facilities in response to the demands for change and needs of the society</li>
      <li>Enhance research consciousness in discovering new dimensions for curriculum development and enrichment</li>
      <li>Implement meaningful and relevant community outreach programs reflective of the available resources and expertise of the university</li>
      <li>Establish strong networking of programs, sharing of resources and expertise with local and international educational institutions and organizations</li>
    </ul>
  </div>
</body>
</html>
