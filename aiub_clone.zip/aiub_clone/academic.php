<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Faculty of Engineering - AIUB</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="icon" type="image/png" href="image/aiublogo.png">
</head>
<body>
  <!-- Header -->
  <header class="top-header">
    <!-- Top Info Bar -->
    <div class="top-info-bar">
      <div class="left-text">
        American International University-Bangladesh
      </div>
      <div class="right-links">
        <span class="icon">🔍</span>
        <a href="login.php">Login</a> |
        <a href="webmail.php">Web Mail</a> |
        <a href="contact_us.php">Contact Us</a>
      </div>
    </div>

    <div class="main-header">
      <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
      <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="academic.php">Academic</a>
        <a href="administration.php">Administration</a>
        <a href="admission.php">Admission</a>
        <a href="research.php">Research</a>
        <a href="notice.php">Notice</a>
        <a href="contact_us.php">Contact</a>
      </nav>
    </div>
  </header>

  <!-- Academic Page Content -->
  <div class="admission-container">
    <div class="section-title">Faculty of Engineering</div>

    <div style="text-align:center;">
      <img src="image/news3.jpeg" alt="FE Logo" style="width: 150px; margin-bottom: 20px;" />
    </div>

    <div class="fe-intro">
      <h3>Vision</h3>
      <p>To be recognized globally for academic excellence through innovation, research, and inclusive learning in engineering education.</p>
      <h3>Mission</h3>
      <p>To prepare competent engineers with ethical values, leadership, and global perspectives who will contribute to the advancement of society and sustainable development.</p>
    </div>

    <div class="messages">
      <div class="policy-boxes">
        <div class="policy-box">
          <img src="image/din.jpg" alt="Dean" style="width:100%; border-radius:8px;">
          <h4>Message from Dean</h4>
          <p>Welcome message from the Dean of the Faculty of Engineering.</p>
          <button><a href="messageFromDean.php">Read More</a></button>
        </div>
        <div class="policy-box">
          <img src="image/assdin.jpg" alt="Associate Dean" style="width:100%; border-radius:8px;">
          <h4>Message from Associate Dean</h4>
          <p>Welcome message from the Associate Dean of the Faculty of Engineering.</p>
          <button><a href="messageFromAssDean.php">Read More</a></button>
        </div>
      </div>
    </div>

    <div class="section-title">Departments</div>
    <ul>
      <li>Electrical & Electronic Engineering (EEE)</li>
      <li>Industrial & Production Engineering (IPE)</li>
      <li>Architecture</li>
      <li>Computer Engineering (CoE)</li>
    </ul>

    <div class="section-title">Programs</div>
    <h4><a href="undergraduatePrograms.php">Undergraduate Programs</a></h4>
    <ul>
      <li>EEE</li>
      <li>IPE</li>
      <li>CoE</li>
      <li>Architecture</li>
    </ul>

    <h4>Graduate Programs</h4>
    <ul>
      <li>Masters in EEE (MEEE)</li>
      <li>Master of Engineering in Telecommunications</li>
    </ul>

    <div class="section-title">Resources</div>
    <div class="policy-boxes">
      <div class="policy-box">
        <h4><a href="student_hand_book.php">Student Hand Book</a></h4>
        <button><a href="student_hand_book.php">Download</a></button>
      </div>
    </div>

    <div class="policy-boxes">
      <div class="policy-box">
        <h4>Research and Publications</h4>
        <button><a href="researchAndPublications.php">Browse Publications</a></button>
      </div>
      <div class="policy-box">
        <h4>Proposal Portal</h4>
        <button><a href="researchAndPublications.php">Research Proposals</a></button>
      </div>
      <div class="policy-box">
        <h4>A.J.E</h4>
        <button>Explore AJE</button>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer about-footer">
    <div class="footer-content">
      <div class="footer-left">
        <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
        <p>American International University-Bangladesh (AIUB)</p>
        <p>Where leaders are created</p>
        <div class="social-icons">
          <a href="#"><img src="image/fb.jpeg" alt="Facebook"></a>
          <a href="#"><img src="image/twt.png" alt="Twitter"></a>
          <a href="#"><img src="image/lindin.png" alt="LinkedIn"></a>
          <a href="#"><img src="image/yt.png" alt="YouTube"></a>
        </div>
      </div>
      <div class="footer-center">
        <h4>Contact</h4>
        <p>Email: info@aiub.edu</p>
        <p>Address: 408/1 (Old KA 66/1), Kuratoli, Khilkhet, Dhaka-1229</p>
        <p>Phone: +88 02 841 4046-9; +88 02 841 4050</p>
      </div>
      <div class="footer-right">
        <h4>Become AIUBian</h4>
        <ul>
          <li><a href="#">Future Students</a></li>
          <li><a href="#">On Campus</a></li>
          <li><a href="#">Admission</a></li>
          <li><a href="#">Tuition Fees</a></li>
          <li><a href="#">Scholarships</a></li>
          <li><a href="#">Apply Now</a></li>
        </ul>
        <h4>Academic</h4>
        <ul>
          <li><a href="#">Academic Calendar</a></li>
          <li><a href="#">Academic Regulations</a></li>
          <li><a href="#">Faculty of Arts & Social Sciences</a></li>
          <li><a href="#">Faculty of Business Administration</a></li>
          <li><a href="#">Faculty of Engineering</a></li>
          <li><a href="#">Faculty of Science & Technology</a></li>
        </ul>
      </div>
    </div>
  </footer>
</body>
</html>
