<?php
// Optional: You can handle form submissions or backend logic here
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About - AIUB</title>
  <link rel="stylesheet" href="about.css" />
  <link rel="icon" type="image/png" href="image/aiublogo.png">
</head>
<body>
  <!-- Header -->
  <header class="top-header">
    <!-- Top Info Bar -->
    <div class="top-info-bar">
      <div class="left-text">
        American International University-Bangladesh
      </div>
      <div class="right-links">
        <span class="icon">🔍</span>
        <a href="login.php">Login</a> |
        <a href="webmail.php">Web Mail</a> |
        <a href="contract_us.php">Contact Us</a>
      </div>
    </div>

    <div class="main-header">
      <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
      <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="academic.php">Academic</a>
        <a href="administration.php">Administration</a>
        <a href="admission.php">Admission</a>
        <a href="research.php">Research</a>
        <a href="notice.php">Notice</a>
        <a href="contract_us.php">Contact</a>
      </nav>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <img src="image/campus-drone-shot-25-june-2024.webp" alt="Hero Banner" />
  </section>

  <!-- Dropdown Menu -->
  <div class="menu-container">
    <button class="menu-button" onclick="toggleDropdown()">
      <div class="hamburger"></div>
      About
    </button>
    <div class="dropdown" id="aboutDropdown">
      <a href="information.php">1. General Information or Overview</a>
      <a href="rules.php">2. Rules of Campus Entry</a>
      <a href="whyStudyHere.php">3. Why Study Here</a>
      <a href="research.php">4. Resources</a>
      <a href="carier.php">5. Career</a>
      <a href="convocation.php">6. Convocation</a>
      <a href="video.php">7. Video</a>
    </div>
  </div>

  <script>
    function toggleDropdown() {
      document.getElementById("aboutDropdown").classList.toggle("show");
    }

    window.onclick = function(e) {
      if (!e.target.closest('.menu-container')) {
        document.getElementById("aboutDropdown").classList.remove("show");
      }
    };
  </script>

  <!-- About Cards Section -->
  <section class="about-cards">
    <div class="card blue">
      <h3>Information</h3>
      <p>AIUB</p>
      <button><a href="info.php">View</a></button>
    </div>
    <div class="card lightblue">
      <h3>General Information</h3>
      <p>AIUB</p>
      <button><a href="information.php">View</a></button>
    </div>
    <div class="card red">
      <h3>Why Study at AIUB?</h3>
      <p>AIUB</p>
      <button><a href="whyStudyHere.php">View</a></button>
    </div>
    <div class="card green">
      <h3>Resources</h3>
      <p>AIUB</p>
      <button><a href="resources.php">View</a></button>
    </div>
    <div class="card purple">
      <h3>Career Opportunity</h3>
      <p>AIUB</p>
      <button><a href="carier.php">View</a></button>
    </div>
    <div class="card teal">
      <h3>Convocation</h3>
      <p>AIUB</p>
      <button><a href="convocation.php">View</a></button>
    </div>
  </section>

  <!-- Footer Section -->
  <footer class="footer about-footer">
    <div class="footer-content">
      <div class="footer-left">
        <img src="image/aiublogo.png" alt="AIUB Logo" class="logo" />
        <p>American International University-Bangladesh (AIUB)</p>
        <p>Where leaders are created</p>
        <div class="social-icons">
          <a href="#"><img src="image/fb.jpeg" alt="Facebook"></a>
          <a href="#"><img src="image/twt.png" alt="Twitter"></a>
          <a href="#"><img src="image/lindin.png" alt="LinkedIn"></a>
          <a href="#"><img src="image/yt.png" alt="YouTube"></a>
        </div>
      </div>
      <div class="footer-center">
        <h4>Contact</h4>
        <p>Email: info@aiub.edu</p>
        <p>Address: 408/1 (Old KA 66/1), Kuratoli, Khilkhet, Dhaka-1229</p>
        <p>Phone: +88 02 841 4046-9; +88 02 841 4050</p>
      </div>
      <div class="footer-right">
        <h4>Become AIUBian</h4>
        <ul>
          <li><a href="#">Future Students</a></li>
          <li><a href="#">On Campus</a></li>
          <li><a href="#">Admission</a></li>
          <li><a href="#">Tuition Fees</a></li>
          <li><a href="#">Scholarships</a></li>
          <li><a href="#">Apply Now</a></li>
        </ul>
        <h4>Academic</h4>
        <ul>
          <li><a href="#">Academic Calendar</a></li>
          <li><a href="#">Academic Regulations</a></li>
          <li><a href="#">Faculty of Arts & Social Sciences</a></li>
          <li><a href="#">Faculty of Business Administration</a></li>
          <li><a href="#">Faculty of Engineering</a></li>
          <li><a href="#">Faculty of Science & Technology</a></li>
        </ul>
      </div>
    </div>
  </footer>
</body>
</html>
