<?php
// video_gallery.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AIUB Video Gallery</title>
  <link rel="stylesheet" href="video.css"/>
</head>
<body>
  <header>
    <div class="topbar">American International University-Bangladesh</div>
    <nav class="navbar">
      <div class="logo">AIUB</div>
      <ul>
        <li><a href="#">About</a></li>
        <li><a href="#">Academics</a></li>
        <li><a href="#">Admission</a></li>
        <li><a href="#">On Campus</a></li>
        <li><a href="#">Administration</a></li>
        <li><a href="#">Research</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="banner">
      <h1>AIUB Video Gallery</h1>
    </section>

    <section class="content">
      <div class="video-grid">
        <!-- Video 1 -->
        <div class="video-card">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_1" frameborder="0" allowfullscreen></iframe>
          <h4>Campus Tour</h4>
          <p>Explore the AIUB campus through this comprehensive tour.</p>
        </div>

        <!-- Video 2 -->
        <div class="video-card">
          <iframe src="https://www.youtube.com/embed/VIDEO_ID_2" frameborder="0" allowfullscreen></iframe>
          <h4>Student Testimonials</h4>
          <p>Hear from our students about their experiences at AIUB.</p>
        </div>

        <!-- Add more video cards as needed -->
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 AIUB. All rights reserved.</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
