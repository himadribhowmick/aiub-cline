<?php
// admission_requirements.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admission Requirements - AIUB</title>
  <link rel="stylesheet" href="undergraduatePrograms.css" />
</head>
<body>
  <header>
    <h1>AIUB Admission Requirements</h1>
  </header>

  <main class="container">
    <section>
      <h2>1. Bachelor of Pharmacy (BPharm)</h2>
      <ul>
        <li>Applicants must be permanent residents of Bangladesh.</li>
        <li>Foreign applicants may apply only for reserved seats allocated by the Government.</li>
        <li>Minimum total GPA of 8.00 in SSC & HSC, with minimum GPA 3.50 in each.</li>
        <li>HSC: GPA 3.50 in Chemistry and Biology; GPA 3.00 in Physics and Mathematics.</li>
        <li>A-Level: Grade 'B' in Chemistry and Biology; Grade 'C' in Physics and Math.</li>
        <li>Math-deficient students must take an extra 3-credit Math course.</li>
        <li>Valid for current year or past 2 years only.</li>
        <li>Foreign applicants need an equivalence certificate from the Pharmacy Council.</li>
      </ul>
    </section>

    <section>
      <h2>2. EEE / IPE / COE / Architecture / B.Sc. (CSE)</h2>
      <ul>
        <li>Total GPA of 5.00, with minimum 2.50 in Science background. Math is required in HSC.</li>
        <li>O-Level GPA 2.5 (no grade below D), A-Level GPA 2.0 (Math must be included).</li>
        <li>Only 1 'E' grade allowed in combined O & A Levels (except Math & Physics).</li>
        <li>IB/High School Diploma requires minimum grade B in Math.</li>
        <li>GED results are not accepted.</li>
      </ul>
    </section>

    <section>
      <h2>3. Bachelor of Business Administration (BBA)</h2>
      <ul>
        <li>Total GPA of 5.00, minimum GPA 2.50 required.</li>
        <li>O-Level GPA 2.5 (no grade below D), A-Level GPA 2.0 in 2 subjects.</li>
        <li>1 'E' grade is acceptable (excluding key subjects).</li>
        <li>IB/High School Diploma requires minimum grade B.</li>
        <li>GED results are not accepted.</li>
      </ul>
    </section>

    <section>
      <h2>4. Arts & Social Sciences (BA English, MMC, BSS Economics, LLB)</h2>
      <ul>
        <li>Total GPA of 5.00, minimum GPA 2.50 required.</li>
        <li>O-Level GPA 2.5, A-Level GPA 2.0 in 2 subjects.</li>
        <li>1 'E' grade is acceptable (excluding key subjects).</li>
        <li>IB/High School Diploma requires minimum grade C.</li>
        <li>GED results are not accepted.</li>
      </ul>
    </section>

    <section>
      <h2>Required Documents</h2>
      <ul>
        <li>Attested photocopy of all mark sheets, certificates/testimonials.</li>
        <li>3 recent formal passport-sized photographs.</li>
        <li>A-Level students: A2 Statement of Entry & Mark Sheets.</li>
        <li>HSC students: Appeared Certificate, Admit Card, and Registration Card.</li>
        <li>Freedom Fighter applicants: multiple documents including National ID, Mukti Barta, and Gazette.</li>
        <li>FF quota candidates must present originals during admission.</li>
      </ul>
    </section>

    <section>
      <h2>Written Exam Waiver Conditions</h2>
      <ul>
        <li>SAT score of ≥ 1650 (out of 2400)</li>
        <li>SAT score of ≥ 1106 (out of 1600)</li>
        <li>Applicants will be called for a viva interview.</li>
      </ul>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 American International University-Bangladesh (AIUB)</p>
  </footer>
</body>
</html>
