<?php
// collaborating-institutes.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Collaborating Institutes | AIUB</title>
  <link rel="stylesheet" href="collaboratingI.css"/>
</head>
<body>
  <header>
    <div class="topbar">American International University-Bangladesh</div>
    <nav class="navbar">
      <div class="logo">AIUB</div>
      <ul>
        <li>About</li>
        <li>Academics</li>
        <li>Admission</li>
        <li>On Campus</li>
        <li>Administration</li>
        <li>Research</li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="banner">
      <h1>Collaborating Institutes</h1>
    </section>

    <section class="content">
      <div class="collaboration-grid">
        <!-- Samsung R&D Institute Bangladesh -->
        <div class="card">
          <h4>Samsung R&D Institute Bangladesh (SRBD)</h4>
          <p><strong>Type:</strong> Industry Collaboration</p>
          <p><strong>Focus:</strong> Mobile Application Development and Research on Tizen OS</p>
          <p><strong>Details:</strong> SRBD, a subsidiary of Samsung Electronics, collaborates with AIUB to integrate Tizen platform development into the curriculum, enhancing skills in wearable and IoT technologies.</p>
        </div>

        <!-- BRAC IT Services Ltd. -->
        <div class="card">
          <h4>BRAC IT Services Ltd. (biTS)</h4>
          <p><strong>Type:</strong> Industry Collaboration</p>
          <p><strong>Focus:</strong> IT Solutions and Services</p>
          <p><strong>Details:</strong> biTS partners with AIUB to provide end-to-end IT solutions across various industries, aiming to enhance operational efficiency through technology.</p>
        </div>

        <!-- Department of Linguistics, University of Dhaka -->
        <div class="card">
          <h4>Department of Linguistics, University of Dhaka</h4>
          <p><strong>Type:</strong> Academic Collaboration</p>
          <p><strong>Focus:</strong> Linguistics Research and Development</p>
          <p><strong>Details:</strong> Collaboration aims to foster research and academic exchange in the field of linguistics.</p>
        </div>

        <!-- BJIT Academy Ltd. -->
        <div class="card">
          <h4>BJIT Academy Ltd.</h4>
          <p><strong>Type:</strong> Industry Collaboration</p>
          <p><strong>Focus:</strong> IT Skill Development</p>
          <p><strong>Details:</strong> Partnership focuses on addressing skill gaps and producing industry-ready IT professionals through specialized training programs.</p>
        </div>

        <!-- University of Trento -->
        <div class="card">
          <h4>University of Trento</h4>
          <p><strong>Type:</strong> Academic Mobility Program</p>
          <p><strong>Focus:</strong> Student Exchange for MSCS, MEEE, and MTEL Programs</p>
          <p><strong>Details:</strong> Mobility program allows eligible AIUB students to take courses at the University of Trento, promoting international academic exposure.</p>
        </div>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 AIUB. All rights reserved.</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
