<?php
// why_study_here.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Why Study at AIUB</title>
  <link rel="stylesheet" href="whyStudyHere.css" />
</head>
<body>
  <div class="container">
    <h1>Why Study Here</h1>
    <p>
      Since its inception, AIUB has been committed to provide, maintain, and enhance an educational environment that is conducive to learning, not only for those who come to learn but also for those who impart it.
    </p>
    <p>
      For over a decade, we have been committed to provide students with an enriching undergraduate and graduate experience, with the right combination of all the essential components required for attaining excellence in learning.
    </p>
    <p>
      All our infrastructural and research facilities, along with the support of competent and compassionate faculty, make AIUB a truly dynamic learning environment, where tomorrow’s leaders are created.
    </p>
    <p>
      If you are looking for a state-of-the-art academic program and a faculty that is second to none, aiming to acquire an educational experience that will propel you towards the future, then AIUB is where you want to be.
    </p>
    <p>
      Over 13,000 students are currently pursuing their dreams, following the footsteps of nearly 40,000 graduates before them, who experienced AIUB’s high standard and excellence in education.
    </p>
    <p>
      Over the years, graduates have successfully placed themselves in every imaginable sphere of the career spectrum, both nationally and internationally, making their mark in the world, doing us and the nation proud.
    </p>
    <p class="highlight">
      So, what are you waiting for? Come, join AIUB, and be a force to be reckoned with!
    </p>
  </div>
</body>
</html>
